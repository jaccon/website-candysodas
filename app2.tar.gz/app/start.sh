#!/bin/bash
docker-compose --project-name="candysodas" up -d

