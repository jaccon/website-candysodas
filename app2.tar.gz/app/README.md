##Pagefai Web Application
The simple web application in container Docker

Requirements:
php7:8
Pagefai Commerce Account

