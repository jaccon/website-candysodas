<div class="section-full p-t140 bg-repeat " style="background-image:url(images/background/ptn-1.png);">
                <div class="container">
                    <div class="section-content">
                        <div class="section-head text-left">
                            <h2 class="text-uppercase font-36">Depoimentos</h2>
                            <div class="wt-separator-outer">
                                <div class="wt-separator bg-black"></div>
                            </div>
                        </div>
                        <div class="section-content">
                            <div class="owl-carousel testimonial-home">
                                <div class="item">
                                    <div class="testimonial-6">
                                        <div class="testimonial-pic-block"> 
                                            <div class="testimonial-pic">
                                                <img src="images/testimonials/pic1.jpg" width="132" height="132" alt="">
                                            </div>
                                        </div>
                                        <div class="testimonial-text clearfix bg-white">
                                            <div class="testimonial-detail clearfix">
                                                <strong class="testimonial-name">Taylor Roberts</strong>
                                                <span class="testimonial-position p-t0">Co-manager associated</span>
                                            </div>
                                            <div class="testimonial-paragraph text-black p-t15">
                                                <span class="fa fa-quote-left"></span>
                                                <p>typefaces and layouts, and in appearance of different general the content of dummy text is nonsensical.typefaces of dummy text is nonsensical.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="testimonial-6">
                                        <div class="testimonial-pic-block"> 
                                            <div class="testimonial-pic">
                                                <img src="images/testimonials/pic4.jpg" width="132" height="132" alt="">
                                            </div>
                                        </div>
                                        <div class="testimonial-text clearfix bg-white">
                                            <div class="testimonial-detail clearfix">
                                                <strong class="testimonial-name">Robert willson</strong>
                                                <span class="testimonial-position p-t0">Co-manager associated</span>
                                            </div>
                                            <div class="testimonial-paragraph text-black p-t15">
                                                <span class="fa fa-quote-left"></span>
                                                <p>typefaces and layouts, and in appearance of different general the content of dummy text is nonsensical.typefaces of dummy text is nonsensical.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>                                
                                <div class="item">
                                    <div class="testimonial-6">
                                        <div class="testimonial-pic-block"> 
                                            <div class="testimonial-pic">
                                                <img src="images/testimonials/pic2.jpg" width="132" height="132" alt="">
                                            </div>
                                        </div>
                                        <div class="testimonial-text clearfix bg-white">
                                            <div class="testimonial-detail clearfix">
                                                <strong class="testimonial-name">Taylor Roberts</strong>
                                                <span class="testimonial-position p-t0">Co-manager associated</span>
                                            </div>
                                            <div class="testimonial-paragraph text-black p-t15">
                                                <span class="fa fa-quote-left"></span>
                                                <p>typefaces and layouts, and in appearance of different general the content of dummy text is nonsensical.typefaces of dummy text is nonsensical.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>                                
                                <div class="item">
                                    <div class="testimonial-6">
                                        <div class="testimonial-pic-block"> 
                                            <div class="testimonial-pic">
                                                <img src="images/testimonials/pic3.jpg" width="132" height="132" alt="">
                                            </div>
                                        </div>
                                        <div class="testimonial-text clearfix bg-white">
                                            <div class="testimonial-detail clearfix">
                                                <strong class="testimonial-name">Robert willson</strong>
                                                <span class="testimonial-position p-t0">Co-manager associated</span>
                                            </div>
                                            <div class="testimonial-paragraph text-black p-t15">
                                                <span class="fa fa-quote-left"></span>
                                                <p>typefaces and layouts, and in appearance of different general the content of dummy text is nonsensical.typefaces of dummy text is nonsensical.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="testimonial-6">
                                        <div class="testimonial-pic-block"> 
                                            <div class="testimonial-pic">
                                                <img src="images/testimonials/pic1.jpg" width="132" height="132" alt="">
                                            </div>
                                        </div>
                                        <div class="testimonial-text clearfix bg-white">
                                            <div class="testimonial-detail clearfix">
                                                <strong class="testimonial-name">Taylor Roberts</strong>
                                                <span class="testimonial-position p-t0">Co-manager associated</span>
                                            </div>
                                            <div class="testimonial-paragraph text-black p-t15">
                                                <span class="fa fa-quote-left"></span>
                                                <p>typefaces and layouts, and in appearance of different general the content of dummy text is nonsensical.typefaces of dummy text is nonsensical.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                                <div class="item">
                                    <div class="testimonial-6">
                                        <div class="testimonial-pic-block"> 
                                            <div class="testimonial-pic">
                                                <img src="images/testimonials/pic4.jpg" width="132" height="132" alt="">
                                            </div>
                                        </div>
                                        <div class="testimonial-text clearfix bg-white">
                                            <div class="testimonial-detail clearfix">
                                                <strong class="testimonial-name">Taylor Roberts</strong>
                                                <span class="testimonial-position p-t0">Co-manager associated</span>
                                            </div>
                                            <div class="testimonial-paragraph text-black p-t15">
                                                <span class="fa fa-quote-left"></span>
                                                <p>typefaces and layouts, and in appearance of different general the content of dummy text is nonsensical.typefaces of dummy text is nonsensical.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>                                                                                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container">
                    	<div class="hilite-title p-lr20 m-tb20 text-right text-uppercase bdr-gray bdr-right">
                            <strong>Clientes </strong>
                            <span class="text-black"> dizem</span>
                        </div>
                    </div>                
            </div>  