#!/bin/bash
docker-compose --project-name="candysodas" down 

