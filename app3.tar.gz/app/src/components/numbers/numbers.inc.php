<style>
    .background-video {
      position: relative;
      width: 100%;
      height: 300px;
      background-color: black;
      overflow: hidden;
    }

    .background-video {
        position: absolute;
        width: 100%;
        height: 520px;
        background-color: black;
        overflow: hidden;
        margin-top: -100px;
    }

    
  </style>


<div class="section-full p-tb100 overlay-wraper bg-top-center bg-parallax"  data-stellar-background-ratio="0.5" >
    
    <div class="background-video">
        <iframe src="https://player.vimeo.com/video/832992873?autoplay=1&amp;loop=1&amp;autopause=0&muted=1" frameborder="0" 
            webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
    </div>

    <div class="row">
                    
    
    <div class="overlay-main opacity-08 bg-black"></div>
    <div class="container ">
                        <div class="col-md-6 col-sm-12">
                        	<div class="some-facts">
                        		<div class="text-white text-uppercase">
                                <span class="font-40 font-weight-300"> </span>
                                <h2 class="font-50">
                                    <span class="text-orange"> Casa 8</span>
                                </h2>
                                <p class="font-18 font-weight-300">
                                    Descubra a sofisticação dos seus sonhos com a Casa 8 Arquitetura e Design
                                </p>
                            </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
            
            
