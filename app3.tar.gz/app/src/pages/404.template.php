<?php 
include('../config.inc.php');
global $CONFIG;
$siteUrl = $CONFIG['CONF']['siteUrl'];

$title = "404";
$content = "Não encontramos a página que está pesquisando. Volte para a home e aproveite todas as demais produtos que temos pra você";
$buttonText="Voltar para Home";

?>
